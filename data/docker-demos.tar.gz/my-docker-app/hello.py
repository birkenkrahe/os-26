import os

print("Hello from inside a customer Docker container!")
print(f"I am running on: {os.uname().sysname}")
